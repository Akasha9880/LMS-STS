package com.lms.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lms.dto.EmployeeDto;
import com.lms.entity.Employee;
import com.lms.service.EmployeeService;
//import com.lms.util.EmailService;
import com.lms.util.EmailService;



@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private EmailService emailService;
	// Handler methods

	// http://localhost:8080/view
	//  

	@RequestMapping("/view")
	public String viewCreateRegistrationPage() {
		return "create_employee";
	}

	// method one
//	@RequestMapping("/addEmployee")
//	public String addEmployee(
//			@ModelAttribute Employee employee,
//			ModelMap model
//			) {
//		employeeService.addEmployee(employee);
//		model.addAttribute("msg","Record is saved");
//		return "create_employee";
//	}

	// method two
//	@RequestMapping("/addEmployee")
//	public String addEmployee(
//			@RequestParam String  name,
//			@RequestParam String emailId,
//			@RequestParam String mobile,
//			ModelMap model
//			) {
//		
//		Employee employee = new Employee();
//		employee.setName(name);
//		employee.setEmailId(emailId);
//		employee.setMobile(mobile);
//		employeeService.addEmployee(employee);
//		model.addAttribute("msg","Record is saved");
//		return "create_employee";
//	}

	// methods three of reading the data from the database
	@RequestMapping("/addEmployee")
	public String addEmployee(EmployeeDto dto, ModelMap model) {

		Employee employee = new Employee();
		employee.setName(dto.getName());
		employee.setEmailId(dto.getEmailId());
		employee.setMobile(dto.getMobile());
		employeeService.addEmployee(employee);
		
		emailService.sendEmail(dto.getEmailId(), "Welcome", "hi, welcome to...");
		model.addAttribute("msg", "Record is saved");
		return "create_employee";
	}

	@RequestMapping("/getAllEmp")
	public String getAllEmp(ModelMap model) {
		List<Employee> employees = employeeService.getAllEmployees();
		model.addAttribute("employees", employees);
		return "list_employees";
	}

	@RequestMapping("/deleteReg")
	public String deletReg(@RequestParam Long id, ModelMap model) {
		// requestparam can fetch the value from the url
		employeeService.deleteRegistration(id);
		List<Employee> employees = employeeService.getAllEmployees();
		model.addAttribute("employees", employees);
		return "list_employees";
	}

	@RequestMapping("/updateReg")
	public String updateReg(@RequestParam long id, ModelMap model) {
		Employee employee = employeeService.getEmployeeById(id);
		model.addAttribute("employee", employee);
		return "update_employee";
	}

	@RequestMapping("/updateEmployee")
	public String updateRegistration(
			EmployeeDto dto, ModelMap model)
	{ 
		employeeService.updateEmployee(dto);
		
		List<Employee> employees = employeeService.getAllEmployees();
		model.addAttribute("employees", employees);
		return "list_employees";
	}
}
