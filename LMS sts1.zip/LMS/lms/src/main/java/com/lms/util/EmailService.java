package com.lms.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component //this(@Service) is the sterio type annotations
public class EmailService {
	
	//in order to click on the send button create reference variable of type
	//and perform dependency injection
	@Autowired
	private JavaMailSender javaMailSender;
	public void sendEmail(
			String to,
			String sub,
			String msg
			) {
		
		SimpleMailMessage s = new SimpleMailMessage();
		s.setTo(to);
		s.setSubject(sub);
		s.setText(msg);
		javaMailSender.send(s);
		
	}	
}
