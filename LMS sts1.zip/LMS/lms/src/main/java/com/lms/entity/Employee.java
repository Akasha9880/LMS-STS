package com.lms.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "employees")
public class Employee {

	@Id
	// id will be automatically populated in the database
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "name", length = 45, nullable = false)
	private String name;
//these are the constraints on the database columns
	@Column(name = "email_id", unique = true, nullable = false, length = 128)
	private String emailId;
	
	@Column (name="mobile", unique = true, nullable = false, length = 10)
	private String mobile;

	public long getId() { 
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

}
